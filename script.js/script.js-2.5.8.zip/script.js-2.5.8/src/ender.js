var s = require('scriptjs')
ender.ender({
    script: s
  , require: s
  , ready: s.ready
  , getScript: s.get
});
